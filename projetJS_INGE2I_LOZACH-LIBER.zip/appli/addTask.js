const axios = require('axios');
const readline = require('readline');

function addTask() {
  return new Promise((resolve, reject) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question('Nom de la tâche : ', (name) => {
      rl.question('Date d\'échéance : ', (dueDate) => {
        rl.question('Priorité : ', (priority) => {
          rl.question('Statut : ', (status) => {
            const taskData = {
              name: name,
              dueDate: dueDate,
              priority: priority,
              status: status
            };

            axios.post('http://localhost:5000/task', taskData)
              .then(response => {
                console.log('Tâche ajoutée :', response.data);
                rl.close();
                resolve();
              })
              .catch(error => {
                console.error('Erreur lors de l\'ajout de la tâche :', error);
                rl.close();
                reject(error);
              });
          });
        });
      });
    });
  });
}

function updateTask() {
  return new Promise((resolve, reject) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question('ID de la tâche à mettre à jour : ', (taskId) => {
      rl.question('Nouveau nom de la tâche : ', (name) => {
        rl.question('Nouvelle date d\'échéance : ', (dueDate) => {
          rl.question('Nouvelle priorité : ', (priority) => {
            rl.question('Nouveau statut : ', (status) => {
              const taskData = {
                name: name,
                dueDate: dueDate,
                priority: priority,
                status: status
              };

              axios.put(`http://localhost:5000/tasks/${taskId}`, taskData)
                .then(response => {
                  console.log('Tâche mise à jour :', response.data);
                  rl.close();
                  resolve();
                })
                .catch(error => {
                  console.error('Erreur lors de la mise à jour de la tâche :', error);
                  rl.close();
                  reject(error);
                });
            });
          });
        });
      });
    });
  });
}

function deleteTask() {
  return new Promise((resolve, reject) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question('ID de la tâche à supprimer : ', (taskId) => {
      axios.delete(`http://localhost:5000/tasks/${taskId}`)
        .then(() => {
          console.log('Tâche supprimée');
          rl.close();
          resolve();
        })
        .catch(error => {
          console.error('Erreur lors de la suppression de la tâche :', error);
          rl.close();
          reject(error);
        });
    });
  });
}

function getTasks() {
  return new Promise((resolve, reject) => {
    axios.get('http://localhost:5000/tasks')
      .then(response => {
        console.log('Liste des tâches :', response.data);
        resolve();
      })
      .catch(error => {
        console.error('Erreur lors de la récupération des tâches :', error);
        reject(error);
      });
  });
}

function main() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.question('Que souhaitez-vous faire ? (add/update/delete/get) : ', (choice) => {
    rl.close();

    let operationPromise;

    if (choice === 'add') {
      operationPromise = addTask();
    } else if (choice === 'update') {
      operationPromise = updateTask();
    } else if (choice === 'delete') {
      operationPromise = deleteTask();
    } else if (choice === 'get') {
      operationPromise = getTasks();
    } else {
      console.log('Choix invalide.');
      operationPromise = Promise.reject();
    }

    operationPromise
      .then(() => {
        console.log('Opération terminée.');
      })
      .catch(() => {
        console.log('Une erreur s\'est produite.');
      });
  });
}

main();
