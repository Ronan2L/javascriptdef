const axios = require('axios');



const express = require('express');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars').create({ defaultLayout: 'main', extname: '.hbs' });
const fs = require('fs');
const csv = require('fast-csv');
const path = require('path');

const app = express();
const port = 5000;

app.engine('hbs', exphbs.engine);
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

class Task {
    constructor(id, name, dueDate, priority, status) {
        this.id = id;
        this.name = name;
        this.dueDate = dueDate;
        this.priority = priority;
        this.status = status;
    }
}

function loadTasks(filePath) {
    return new Promise((resolve, reject) => {
        const tasks = [];
        fs.createReadStream(filePath)
            .pipe(csv.parse({ headers: true }))
            .on('data', (row) => {
                const id = row.id !== undefined ? parseInt(row.id) : null;
                const task = new Task(
                    id,
                    row.name,
                    row.dueDate,
                    row.priority,
                    row.status
                );
                tasks.push(task);
            })
            .on('end', () => {
                console.log('Le CSV a été lu correctement.');
                resolve(tasks);
            })
            .on('error', (error) => {
                reject(error);
            });
    });
}

function saveTasks(filePath, tasks) {
    return new Promise((resolve, reject) => {
        const csvStream = csv.format({ headers: true });
        csvStream
            .pipe(fs.createWriteStream(filePath))
            .on('finish', () => {
                console.log('Le fichier tasks.csv a été mis à jour.');
                resolve();
            })
            .on('error', (error) => {
                reject(error);
            });

        tasks.forEach((task, index) => {
            if (!task.id) task.id = index + 1;
            csvStream.write({
                id: task.id.toString(),
                name: task.name,
                dueDate: task.dueDate,
                priority: task.priority,
                status: task.status,
            });
        });

        csvStream.end();
    });
}

function createTaskManager() {
    const filePath = 'tasks.csv';
    let tasks = [];
    let taskId = 0;

    return {
        loadTasks: () => {
            return loadTasks(filePath)
                .then((loadedTasks) => {
                    tasks = loadedTasks;
                    taskId = tasks.reduce((maxId, task) => Math.max(maxId, task.id), 0);
                });
        },

        saveTasks: () => {
            return saveTasks(filePath, tasks);
        },

        addTask: (name, dueDate, priority, status) => {
            taskId++;
            const task = new Task(taskId, name, dueDate, priority, status);
            tasks.push(task);
            return saveTasks(filePath, tasks).then(() => task);
        },

        updateTask: (id, updatedData) => {
            const taskIndex = tasks.findIndex((task) => task.id === id);
            if (taskIndex === -1) {
                return Promise.reject(new Error('Tâche introuvable !'));
            }

            tasks[taskIndex] = { ...tasks[taskIndex], ...updatedData };
            return saveTasks(filePath, tasks).then(() => tasks[taskIndex]);
        },

        deleteTask: (id) => {
            const taskIndex = tasks.findIndex((task) => task.id === id);
            if (taskIndex === -1) {
                return Promise.reject(new Error('Tâche introuvable !'));
            }

            tasks.splice(taskIndex, 1);
            return saveTasks();
        },

        getTasks: (query) => {
            let filteredTasks = tasks;

            if (query.status) {
                filteredTasks = filteredTasks.filter(
                    (task) => task.status === query.status
                );
            }

            if (query.priority) {
                filteredTasks = filteredTasks.filter(
                    (task) => task.priority === query.priority
                );
            }

            return filteredTasks;
        }
    };
}

const taskManager = createTaskManager();
taskManager.loadTasks().catch((error) => {
    console.error('Erreur lors du chargement de la tâche.', error);
});

app.post('/task', (req, res) => {
    taskManager.addTask(req.body.name, req.body.dueDate, req.body.priority, req.body.status)
        .then((task) => {
            res.json(task);
        });
});

app.put('/tasks/:id', (req, res) => {
    const taskId = parseInt(req.params.id);
    taskManager.updateTask(taskId, req.body)
        .then((task) => {
            res.json(task);
        })
        .catch((error) => {
            res.status(404).json({ error: 'Tâche introuvable !' });
        });
});

app.delete('/tasks/:id', (req, res) => {
    const taskId = parseInt(req.params.id);
    taskManager.deleteTask(taskId)
        .then(() => {
            res.status(204).end();
        })
        .catch((error) => {
            res.status(404).json({ error: 'Tâche introuvable !' });
        });
});

app.get('/tasks', (req, res) => {
    const filteredTasks = taskManager.getTasks(req.query);
    res.json(filteredTasks);
});

app.get('/', (req, res) => {
    res.render('tasks', { tasks: taskManager.getTasks({}) });
});

app.use(express.static('public'));

app.listen(port, () => {
    console.log(`Le serveur Express écoute sur le port ${port}.`);
});


