Bonjour Monsieur, voici mon projet de Javascript du Semestre.
N'ayant pas assité à beaucoup de cours j'ai essayé de faire au mieux avec les ressources d'internet.

J'ai cru comprendre que le but du TP était de jouer sur un CSV et un serveur, c'est donc ce que j'ai fait ici.
J'avais inititialement souhaité faire une interface graphique mais ayant plusieurs matières à rattraper en ce moment j'ai été un peu pris de court.
C'est pourquoi je vous envoie ce travail en l'état: un agenda sobre à partir d'un CSV qui se met à jour à chaque ajout, mise à jour ou suppression d'une tâche.

J'ai essayé au maximum possible de repsecter ce que j'ai compris de la programmation focntiionnelle.
J'espère que le résultat vous satisfera et saura rattraper un minimum ma note à l'examen écrit.



Voici les étapes à suivre pour le code:

	- Dans le Terminal, dans le répertoire du projet, entrer "node index.js"
	- Dans un Second Terminal, dans le répertoire du projet, entrer "node addTask.js"
	- Choisisais les actions que vous voulez mener:

		- add (METHODE POST) pour ajouter une tâche
		- update (METHODE PUT) pour maj une tâche
		- delete (METHODE DELETE) pour supprimer une tâche
		- get (METHODE GET) pour afficher les tâches

	- Une fois chaque action effectuée, addTask s'arrête et le CSV tasks.csv se met à jour.


Cette boucle peut être répétée autant de fois que souhaité.




  